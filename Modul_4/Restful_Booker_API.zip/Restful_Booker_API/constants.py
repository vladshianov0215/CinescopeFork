BASE_URL = "https://restful-booker.herokuapp.com"
HEADERS = {
    "Content-Type": "application/json",
    "Accept": "application/json"
}
